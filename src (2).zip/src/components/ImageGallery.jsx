

import React from "react";
import { Gallery } from "./Constant"

const ImageGallery = () => {
  return (
    <>
      <div className="container ">
        <div className="row Gallery">
          <h2 className="text-center  p-2">Gallery</h2>
          {Gallery.map((item, index) => (
            <div key={index} className="col-sm-3 mb-4 col-6">
              {" "}
              {/* Each image gets its own column */}
              <div className="card">
                <img
                  src={item.img}
                  alt={`Gallery image ${index + 1}`}
                  className="card-img-top"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default ImageGallery;
